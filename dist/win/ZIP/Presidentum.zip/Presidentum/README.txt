This is an academic project, licensed under GNU General Public License v3. 

This project was made at 2016 by Carlos Aniorte Llanes, Alfonso Jos� Rodriguez G�mez, Aitor Vidal Arnau, Ismael Perruca Ja�n, Daniela Posas Padilla and it was also updated and fixed at 2018 by Carlos Aniorte Llanes.

For this project, third party software used was: TinyXml2, Tiled and SFML.
Language used is C++11 and was compiled with GCC 6.1.0 compiler (MinGW)

Thank you for give us your time to review our work.

BitCrushers Team - 2018

Carlos Aniorte Llanes           <carlos.aniortellanes@gmail.com>
Alfonso Jos� Rodriguez G�mez    <alfonsojrg19@gmail.com>
Aitor Vidal Arnau               <showzen@hotmail.es>
Ismael Perruca Ja�n             <ismap1993@gmail.com>
Daniela Posas Padilla           <daniela_mnl_92@hotmail.com>

